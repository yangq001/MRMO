library(MASS)
library(mvtnorm)
library(OpenMx)
library(hydroGOF)
library(statmod)
library(lme4)
library(aSPU)
library(MASS)
library(mvtnorm)
library(OpenMx)
library(hydroGOF)
library(statmod)
library(lme4)
library(aSPU)


MRMO=function(G1,X1,G2,Y2,q1,q2,newton=0,pow=c(1:8, Inf),n.perm=1000){
  if(q1>0){
    which_bin=1:q1
    if(q2==0){
      which_cont=c()
    }else{
      which_cont=(q1+1):(q1+q2)
    }
  }else{
    which_bin=c()
    which_cont=1:q2
  }
  model1=lm(X1~G1)
  GG2=cbind(rep(1,nrow(G2)),G2)
  Xhat=c(GG2%*%model1$coefficients)
  result=MRMOb(Xhat=Xhat,Ys=Y2,which_bin=which_bin,which_cont=which_cont,newton=newton,pow=pow,n.perm=n.perm)
  colnames(result)[4]="MRMO"
  return(result)
}


